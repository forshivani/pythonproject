from tkinter import messagebox
from tkinter import *
import random
import time;
import sqlite3
import datetime
rand,Fries,Samosa,Chicken,Chicken_Burger,Cheese_Burger,Subtotal,Total,Service_charge,Tax,Cost,Drinks= 'none','none','none','none','none','none','none','none','none','none','none','none'
date_time = datetime.datetime.now()
date_time = date_time.strftime("%m/%d/%Y")
print(date_time)
def search():
  global rand,Fries,Samosa,Chicken,Chicken_Burger,Cheese_Burger,Drink,Subtotal,Total,Service_charge,Tax,Cost
  mycursor=sqlite3.connect('E:/food.db')
  data=mycursor.execute('select *from food')
  for row in data:
    print(row)

  global rand,Fries,Samosa,Chicken,Chicken_Burger,Cheese_Burger,Drink,Subtotal,Total,Service_charge,Tax,Cost
  try:
   
    a = rand.get()
    b = Fries.get()
    c = Samosa.get()
    d = Chicken.get()
    e = Chicken_Burger.get()
    f = Cheese_Burger.get()
    g = Drinks.get()
    h = Tax.get()
    i = Subtotal.get()
    j = Total.get()
    k = Service_charge.get()
    l = Cost.get()
    print(a,b,c,d,e,f,g,h,i,j,k,l)
    query = "INSERT INTO food values('%s', '%s','%s', '%s','%s', '%s', '%s' ,'%s','%s', '%s','%s', '%s')" %(a,b,c,d,e,f,g,h,i,j,k,l)
    mycursor.execute(query)
    mycursor.commit()
  except sqlite3.Error as e:
    print(e)
  



root = Tk()
root.geometry("1600x800+0+0")
root.title("Resaurant Mangament System")

text_Input = StringVar()
operator = ""

Tops = Frame(root, width=1600, height=50)
Tops.pack(side=TOP)

f1 = Frame(root, width=800, height=700)
f1.pack(side=LEFT)

f2 = Frame(root, width=800, height=700, )
f2.pack(side=RIGHT)

localtime = time.asctime(time.localtime(time.time()))

l1 = Label(Tops, font=('arial', 50, 'bold'), text="Restaurant Mangament System", fg="Steel Blue", bd=10)
l1.grid(row=0, column=0)
lblDateTime = Label(Tops, font=('arial', 50, 'bold'), text=localtime, fg="Steel Blue",bd=10)
lblDateTime.grid(row=1, column=0)

def btnClick(numbers):
     global operator
     operator = operator + str(numbers)
     text_Input.set(operator)


def btnClearDisplay():
    global rand,Fries,Samosa,Chicken,Chicken_Burger,Cheese_Burger,Subtotal,Total,Service_charge,Tax,Cost,operator
    operator = ""
    text_Input.set("")


def btnEqualsInput():
    global rand,Fries,Samosa,Chicken,Chicken_Burger,Cheese_Burger,Subtotal,Total,Service_charge,Tax,Cost,operator
    sumup = str(eval(operator))
    operator = ""
    text_Input.set(sumup)


def Ref():
    global rand,Fries,Samosa,Chicken,Chicken_Burger,Cheese_Burger,Subtotal,Total,Service_charge,Tax,Cost,operator
    x = random.randint()
    randomRef = str(x)


def Exit():
    root.destroy()


def Reset():
    global rand,Fries,Samosa,Chicken,Chicken_Burger,Cheese_Burger,Subtotal,Total,Service_charge,Tax,Cost,operator
    rand.set("")
    Fries.set("")
    Samosa.set("")
    Chicken.set("")
    Chicken_Burger.set("")
    Cheese_Burger.set("")
    Subtotal.set("")
    Total.set("")
    Service_charge.set("")
    Drinks.set("")
    Tax.set("")
    Cost.set("")
    
rand = StringVar()
Fries = StringVar()
Samosa = StringVar()
Chicken = StringVar()
Chicken_Burger = StringVar()
Cheese_Burger=StringVar()
Subtotal = StringVar()
Total = StringVar()
Service_charge = StringVar()
Drinks = StringVar()
Tax =StringVar()
Cost = StringVar()


txtDisplay= Entry(f2,font=('arial',20,'bold'), textvariable=text_Input, bd=30, insertwidth=4, bg="powder blue", justify='right')
txtDisplay.grid(columnspan=4)
Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="7",bg="powder blue",command=lambda: btnClick(7)).grid(row=2,column=0)
Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="8",bg="powder blue",command=lambda: btnClick(8)).grid(row=2,column=1)
Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="9",bg="powder blue",command=lambda: btnClick(9)).grid(row=2,column=2)
Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="+",bg="powder blue",command=lambda: btnClick("+")).grid(row=2,column=3)
Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="4",bg="powder blue",command=lambda: btnClick(4)).grid(row=3,column=0)
Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="5",bg="powder blue",command=lambda: btnClick(5)).grid(row=3,column=1)
Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="6",bg="powder blue",command=lambda: btnClick(6)).grid(row=3,column=2)
Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="-",bg="powder blue",command=lambda: btnClick("-")).grid(row=3,column=3)

Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="1",bg="powder blue",command=lambda:btnClick(1)).grid(row=4,column=0)
Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="2",bg="powder blue",command= lambda:btnClick(2)).grid(row=4,column=1)
Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="3",bg="powder blue",command=lambda: btnClick(3)).grid(row=4,column=2)
Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="*",bg="powder blue",command=lambda: btnClick("*")).grid(row=4,column=3)

btn0=Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="0",bg="powder blue",command=lambda:btnClick(0)).grid(row=5,column=0)
btnClear=Button(f2,padx=16,pady=16,bd=8,fg="red",font=('arial',20,'bold'),text="C",bg="powder blue",command=btnClearDisplay).grid(row=5,column=1)
btnEquals=Button(f2,padx=16,pady=16,bd=8,fg="red",font=('arial',20,'bold'),text="=",bg="powder blue",command=btnEqualsInput).grid(row=5,column=2)
Division=Button(f2,padx=16,pady=16,bd=8, fg="red",font=('arial',20,'bold'),text="/",bg="powder blue",command=lambda: btnClick("/")).grid(row=5,column=3)


lblReference = Label(f1, font=('arial', 16, 'bold'), text="Reference", bd=16)
lblReference.grid(row=0, column=0)
txtReference = Entry(f1, font=('arial', 16, 'bold'), textvariable=rand, insertwidth=4,
                     bg="powder blue", justify='right')
txtReference.grid(row=0, column=1)

lblFries = Label(f1, font=('arial', 16, 'bold'), text="Large Fries", bd=16)
lblFries.grid(row=1, column=0)
txtFries = Entry(f1, font=('arial', 16, 'bold'), textvariable=Fries,  insertwidth=4,
                 bg="powder blue", justify='right')
txtFries.grid(row=1, column=1)

lblChicken = Label(f1, font=('arial', 16, 'bold'), text="Yummy Chicken", bd=16)
lblChicken.grid(row=2, column=0)
txtChicken = Entry(f1, font=('arial', 16, 'bold'), textvariable=Chicken,  insertwidth=4,
                   bg="powder blue", justify='right')
txtChicken.grid(row=2, column=1)

lblSamosa = Label(f1, font=('arial', 16, 'bold'), text="Tasty Samosa", bd=16)
lblSamosa.grid(row=3, column=0)
txtSamosa = Entry(f1, font=('arial', 16, 'bold'), textvariable=Samosa,  insertwidth=4,
                  bg="powder blue", justify='right')
txtSamosa.grid(row=3, column=1)

lblChicken_Burger = Label(f1, font=('arial', 16, 'bold'), text="Chicken_Burger", bd=16)
lblChicken_Burger.grid(row=4, column=0)
txtChicken_Burger = Entry(f1, font=('arial', 16, 'bold'), textvariable=Chicken_Burger,  insertwidth=4,
                          bg="powder blue", justify='right')
txtChicken_Burger.grid(row=4, column=1)

lblCheese_Burger = Label(f1, font=('arial', 16, 'bold'), text="Cheese_Burger", bd=16)
lblCheese_Burger.grid(row=5, column=0)
txtCheese_Burger = Entry(f1, font=('arial', 16, 'bold'), textvariable=Cheese_Burger, insertwidth=4,
                         bg="powder blue", justify='right')
txtCheese_Burger.grid(row=5, column=1)

lblDrinks = Label(f1, font=('arial', 16, 'bold'), text="Drinks", bd=16)
lblDrinks.grid(row=0, column=2)
txtDrinks = Entry(f1, font=('arial', 16, 'bold'), textvariable=Drinks,  insertwidth=4,
                  bg="powder blue", justify='right')
txtDrinks.grid(row=0, column=3)

lblSubtotal = Label(f1, font=('arial', 16, 'bold'), text="Subtotal", bd=16)
lblSubtotal.grid(row=1, column=2)
txtSubtotal = Entry(f1, font=('arial', 16, 'bold'), textvariable=Subtotal,  insertwidth=4,
                    bg="powder blue", justify='right')
txtSubtotal.grid(row=1, column=3)

lblTotal = Label(f1, font=('arial', 16, 'bold'), text="Total", bd=16)
lblTotal.grid(row=2, column=2)
txtTotal = Entry(f1, font=('arial', 16, 'bold'), textvariable=Total, insertwidth=4,
                 bg="powder blue", justify='right')
txtTotal.grid(row=2, column=3)

lblService_charge = Label(f1, font=('arial', 16, 'bold'), text="Service_charge", bd=16)
lblService_charge.grid(row=3, column=2)
txtService_charge = Entry(f1, font=('arial', 16, 'bold'), textvariable=Service_charge,  insertwidth=4,
                          bg="powder blue", justify='right')
txtService_charge.grid(row=3, column=3)

lblTax = Label(f1, font=('arial', 16, 'bold'), text="Tax", bd=16)
lblTax.grid(row=4, column=2)
txtTax = Entry(f1, font=('arial', 16, 'bold'), textvariable=Tax, insertwidth=4,
               bg="powder blue", justify='right').grid(row=4, column=3)

lblCost = Label(f1, font=('arial', 16, 'bold'), text="Cost", bd=16)
lblCost.grid(row=5, column=0)
txtCost = Entry(f1, font=('arial', 16, 'bold'), textvariable=Cost,  insertwidth=4,
                bg="powder blue", justify='right')
txtCost.grid(row=5, column=1)

btnTotal = Button(f1, padx=16, pady=8, bd=16, fg="blue", font=('arial', 16, 'bold'), width=10, text="Entry",
                  bg="light blue", command=search).grid(row=7, column=1
                                                      )
btnReset = Button(f1, padx=16, pady=8, bd=16, fg="blue", font=('arial', 16, 'bold'), width=10, text="Reset",
                  bg="light blue", command=Reset).grid(row=7, column=2
                                                        )
btnExit = Button(f1, padx=16, pady=8, bd=16, fg="blue", font=('arial', 16, 'bold'), width=10, text="Exit",
                 bg="light blue", command=Exit).grid(row=7, column=3)


root.mainloop()

